# Databricks notebook source
# MAGIC %run ./3.0_Preparing_Model